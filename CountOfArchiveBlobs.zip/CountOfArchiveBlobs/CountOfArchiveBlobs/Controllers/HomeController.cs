﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;

namespace CountOfArchiveBlobs.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings.Get("StorageConnectionString"));
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("yourContainerName");
            var list = container.ListBlobs();
            List<CloudBlockBlob> blobs = list.OfType<CloudBlockBlob>().ToList();
            List<string> _notArchivedBlobs = new List<string>();
            int count = 0;
            foreach (var blob in blobs)
            {
                string bName = blob.Name;
                string bSize = blob.Properties.StandardBlobTier.ToString();
                if (bSize == "Archive")
                {
                    count += 1;
                }
                else
                {
                    _notArchivedBlobs.Add(bName);
                }
                
            }
            TempData["Count"] = count;
            TempData["NoArchiveBlob"] = _notArchivedBlobs;
            return View();
        }


    }
}